📊 Excel Dashboard Project | Sales & Customer Insights

Today, I built an interactive Excel dashboard focused on understanding sales performance and customer behavior using key KPIs and business-driven questions.

🔑 Key KPIs Tracked:

Total Orders

Total Quantity Sold

Total Amount (Revenue)

Average Rating

Average Days to Deliver

❓ Business Questions Answered:

What is the trend in the last 13 weeks?

How do our customers prefer to buy?

How many products do customers buy per order?

Which products are most popular?

What is the overall gender split of customers?

Where do our customers live?

How long does it take to ship orders?

How satisfied are our customers?

📈 This dashboard helps convert raw data into actionable insights for decision-making, performance tracking, and business growth.

💡 Tools used: Microsoft Excel (Pivot Tables, KPIs, Charts)

Currently strengthening my skills in data analytics, Excel dashboards, and business insights.
Feedback and suggestions are always welcome!

#DataAnalytics #ExcelDashboard #KPIs #BusinessIntelligence #DataDriven #LearningJourney #Analytics
<img width="1231" height="637" alt="Screenshot 2026-02-03 024452" src="https://github.com/user-attachments/assets/d997f0e6-e880-4f43-8d57-188d640e5814" />
